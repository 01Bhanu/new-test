import axios from "axios";

export const Axios = axios.create({
  baseURL: "http://159.65.157.44"
});
